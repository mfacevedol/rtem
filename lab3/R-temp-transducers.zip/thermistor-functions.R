# --------- labels for axis

# Rt and R using expression
labRt <- expression(italic(R[t])*"(k"*Omega*")") 
labR <- expression(italic(R)*"(k"*Omega*")")
# Rf for legend 
labRf <- paste("Rf=",Rf.k,"kohm")


# using unicode for omega optional
#labRt <- paste("Rt"),"(k","\U03A9",")",sep="")
#labR <- paste("R"),"(k","\U03A9",")",sep="")


# using unicode for degrees
labC <- "\u00B0C"
labTC <- "Temperature (\u00B0C)"

# voltage and sensitivity
labVout <- expression(italic(V[out])*"(V)") 
labSens <- paste(" Sens(mV/",labC,")=",sep="")


# ------------- thermistor functions

B.param <- function(Rt.nom,T.C,B){
 # B parameter model
 # Rt.nom is list(T0.C, R0.k)
 T.K <- T.C + 273; T0.K <- Rt.nom$T0.C+273
 Rt.k <- Rt.nom$R0.k*exp(B*(1/T.K - 1/T0.K))
 return(list(Rt.k=round(Rt.k,2),T.C=T.C))
} 

ckt.div <- function(T.C,Rt.nom,B,Rf.k,R1.k,Vs){
 Rt.k <- B.param(Rt.nom,T.C,B)$Rt.k
 R <- R1.k + Rt.k + Rf.k
 Vout <- Vs*Rf.k/R
 Pow <- (Vs/R)^2*Rt.k
 return(list(T.C=T.C,Vout=round(Vout,3),Pow.mW=round(Pow,3)))
}

specs.transd <- function(x){
 #T.C is seq(min,max,step)
 #Vout is output from ckt div 
 T.C <- x$T.C;  Vout <- x$Vout
 xlm <- lm(Vout~T.C)
 Vout.lsq <- xlm$coefficients[1]+xlm$coefficients[2]*T.C

 nT <- length(T.C); range.C <- T.C[nT]-T.C[1]
 FS <- Vout[nT]-Vout[1]
 sens <- FS/range.C
 # linearity end-points
 Vout.end <- sens*(T.C-T.C[1]) + Vout[1]
 
 # max deviance of response with respect to linear
 dev.lsq <- abs(Vout-Vout.lsq); max.dev.lsq <- max(dev.lsq)
 dev.end <- abs(Vout-Vout.end); max.dev.end <- max(dev.end)
 lin.err.lsq <- 100*max.dev.lsq/FS
 lin.err.end <- 100*max.dev.end/FS

 rms.lsq <- sqrt(sum((Vout-Vout.lsq)^2)/nT) 
 rms.end <- sqrt(sum((Vout-Vout.end)^2)/nT) 
 rms.err.lsq <- 100*rms.lsq/FS
 rms.err.end <- 100*rms.end/FS
 
 result <- list(FS.mV=round(FS*1000,2),range.C=round(range.C,2),
                sens.mV=round(sens*1000,2),
                lin.err.lsq=round(lin.err.lsq,2), 
                lin.err.end=round(lin.err.end,2),
                rms.err.lsq=round(rms.err.lsq,2), 
                rms.err.end=round(rms.err.end,2),
                
                Vout=round(Vout,5),T.C=T.C,
                Vout.end=round(Vout.end,5),Vout.lsq=round(Vout.lsq,5),  
                dev.lsq=round(dev.lsq,5),dev.end=round(dev.end,5))
 return(result)
}

specs.plot <- function(X){
 labC <- "\u00B0C"
 labTC <- "Temperature (\u00B0C)"
 labVout <- expression(italic(V[out])*"(V)") 
 labSens <- paste(" Sens(mV/",labC,")=",sep="")

 matplot(X$T.C, cbind(X$Vout,X$Vout.end,X$Vout.lsq),type="l", col=1, xlab=labTC ,ylab=labVout,lwd=1.5)

 pos <- which(X$dev.end==max(X$dev.end))
 lines(c(X$T.C[pos],X$T.C[pos]),c(X$Vout.end[pos],X$Vout[pos]),lty=2,lwd=2,col="grey")

 pos <- which(X$dev.lsq==max(X$dev.lsq))
 lines(c(X$T.C[pos],X$T.C[pos]),c(X$Vout.lsq[pos],X$Vout[pos]),lty=3,lwd=2,col="grey")
 
 mtext(text=paste("FS(mV)=",X$FS.mV,labSens,X$sens.mV,
                  " Lin Err Ends(%FS)=", X$lin.err.end,
                  " Lin Err LSQ(%FS)=", X$lin.err.lsq),
                  side=3,line=-1,cex=0.6)
 mtext(text=paste(" Lin Err RMS Ends(%FS)=", X$rms.err.end,
                  " Lin Err RMS LSQ(%FS)=", X$rms.err.lsq),
                  side=3,line=-2,cex=0.6)
 legend("bottomright",leg=c("Actual","Linear Ends", "Linear LSQ"),lty=1:3,col=1,cex=0.8,lwd=1.5)

}

self.heat <- function(x,kt){
 labC <- "\u00B0C"
 labTC <- "Temperature (\u00B0C)"
 labVout <- expression(italic(V[out])*"(V)") 
 Vout <- x$Vout
 Ta.C <- x$T.C - x$Pow.mW/kt
 panels(6,6,2,1,pty="m")
 plot(x$T.C,x$T.C,type="l",xlab=labTC,ylab=labTC)
 lines(x$T.C,Ta.C,lty=2)
 legend("bottomright",leg=c("1:1 line","Actual"),lty=1:2,col=1)
 
 matplot(X$Vout, cbind(x$T.C,Ta.C),type="l", col=1, xlab=labVout,ylab=labTC)
 legend("bottomright",leg=c("Tt","Ta"),lty=1:2,col=1,cex=0.8)
}
 

T.Vout <- function(Rt.nom,B,ckt,Vout){
 Rf.k=ckt$Rf.k; R1.k=ckt$R1.k; Vs=ckt$Vs
 Rt.k <- Vs*Rf.k/Vout - R1.k - Rf.k
 T0.K <- T0.K <- Rt.nom$T0.C+273
 Rt0.k <- Rt.nom$R0.k 
 T.K <- (1/T0.K+(1/B)*log(Rt.k/Rt0.k))^-1
 T.C <- T.K - 273
 return(list(Rt.k=round(Rt.k,2),T.C= round(T.C,1)))
 }


# Steinhart Hart
SHart <- function(range,coeff){
 #range = list(Rtmax=4071.186,Rtmin=27.481,dR=-0.1)
 #coeff = list(a=8.27 *10^-4,b=2.08 *10^-4, c= 8.06*10^-8)
 Rt.k <- seq(range$Rtmax,range$Rtmin,range$dR)
 Rt <- Rt.k*1000; nR <- length(Rt)  
 T.K <- 1/(coeff$a+coeff$b*log(Rt)+coeff$c*(log(Rt))^3)
 T.C <- T.K - 273
 return(list(Rt.k=round(Rt.k,2),T.C= round(T.C,1)))
}


ckt.div.SHart <- function(range,coeff,ckt){
 Rt.k <- SHart(range,coeff)$Rt.k
 x <- SHart(range,coeff)
 T.C <- x$T.C
 Rt.k <- x$Rt.k
 R <- ckt$R1.k + Rt.k + ckt$Rf.k
 Vout <- ckt$Vs*ckt$Rf.k/R
 Pow <- (ckt$Vs/R)^2*Rt.k
 return(list(T.C=T.C,Vout=round(Vout,5),Pow.mW=round(Pow,5)))
}
