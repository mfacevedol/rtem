# thermistor functions

B.param <- function(Rt.nom,T.C,B){
 # B parameter model
 # Rt.nom is list(T0.C, R0.k)
 T.K <- T.C + 273; T0.K <- Rt.nom$T0.C+273
 Rt.k <- Rt.nom$R0.k*exp(B*(1/T.K - 1/T0.K))
 return(list(Rt.k=round(Rt.k,2),T.C=T.C))
} 

ckt.div <- function(T.C,Rt.nom,B,Rf.k,R1.k,Vs){
 Rt.k <- B.param(Rt.nom,T.C,B)$Rt.k
 R <- R1.k + Rt.k + Rf.k
 Vout <- Vs*Rf.k/R
 Pow <- (Vs/R)^2*Rt.k
 return(list(T.C=T.C,Vout=round(Vout,3),Pow.mW=round(Pow,3)))
}

specs.transd <- function(x){
 #T.C is seq(min,max,step)
 #Vout is output from ckt div 
 T.C <- x$T.C
 Vout <- x$Vout
 nT <- length(T.C); range.C <- T.C[nT]-T.C[1]
 FS <- Vout[nT]-Vout[1]
 sens <- FS/range.C
 # linearity
 Vout.lin <- sens*(T.C-T.C[1]) + Vout[1]
 # max deviance of response with respect to linear
 dev <- abs(Vout-Vout.lin); max.dev <- max(dev)
 lin.err <- 100*max.dev/FS

 result <- list(FS.mV=round(FS*1000,2),range.C=round(range.C,2),sens.mV=round(sens*1000,2),lin.err.percent=round(lin.err,2), Vout=round(Vout,5), Vout.lin=round(Vout.lin,5), dev=round(dev,5),T.C=T.C)  
 return(result)
}

specs.plot <- function(X){

 matplot(X$T.C, cbind(X$Vout,X$Vout.lin),type="l", col=1, xlab="Temp(�C)",ylab="Vout(V)")
 pos <- which(X$dev==max(X$dev))
 lines(c(X$T.C[pos],X$T.C[pos]),c(X$Vout.lin[pos],X$Vout[pos]),lty=1,lwd=2,col="grey")
 mtext(text=paste("FS(mV)=",X$FS.mV," Sens(mV/�C)=",X$sens.mV," LinErr(%)=",X$lin.err.percent),side=3,line=-1,cex=0.6)
 legend("bottomright",leg=c("Actual","Linear"),lty=1:2,col=1)

}

self.heat <- function(x,kt){
 Vout <- x$Vout
 Ta.C <- x$T.C - x$Pow.mW/kt
 panels(6,6,2,1,pty="m")
 plot(x$T.C,x$T.C,type="l",xlab="Temp(�C)",ylab="Temp(�C)")
 lines(x$T.C,Ta.C,lty=2)
 legend("bottomright",leg=c("1:1 line","Actual"),lty=1:2,col=1)
 
 matplot(X$Vout, cbind(x$T.C,Ta.C),type="l", col=1, xlab="Vout(V)",ylab="Temp(�C)")
 legend("bottomright",leg=c("Tt","Ta"),lty=1:2,col=1)
}
 

T.Vout <- function(Rt.nom,B,ckt,Vout){
 Rf.k=ckt$Rf.k; R1.k=ckt$R1.k; Vs=ckt$Vs
 Rt.k <- Vs*Rf.k/Vout - R1.k - Rf.k
 T0.K <- T0.K <- Rt.nom$T0.C+273
 Rt0.k <- Rt.nom$R0.k 
 T.K <- (1/T0.K+(1/B)*log(Rt.k/Rt0.k))^-1
 T.C <- T.K - 273
 return(list(Rt.k=round(Rt.k,2),T.C= round(T.C,1)))
 }


# Steinhart Hart
SHart <- function(Rtmax=4071.186,Rtmin=27.481,dR=-0.1){
 a <- 8.27 *10^-4; b <- 2.08 *10^-4; c <- 8.06*10^-8
 Rt.k <- seq(Rtmax,Rtmin,dR); Rt <- Rt.k*1000; nR <- length(Rt)  
 T.K <- 1/(a+b*log(Rt)+c*(log(Rt))^3)
 T.C <- T.K - 273
 return(list(Rt.k=round(Rt.k,2),T.C= round(T.C,1)))
}


ckt.div.SHart <- function(Rtmax=4071.186,Rtmin=27.481,dR=-0.01,Rf.k,R1.k,Vs){
 Rt.k <- SHart(Rtmax,Rtmin,dR)$Rt.k
 x <- SHart(Rtmax,Rtmin,dR)
 T.C <- x$T.C
 Rt.k <- x$Rt.k
 R <- R1.k + Rt.k + Rf.k
 gain <- Rf.k/R
 Vout <- Vs*gain
 Pow <- (Vs/R)^2*Rt.k
 return(list(T.C=T.C,gain=round(gain,5),Vout=round(Vout,5),Pow.mW=round(Pow,5)))
}