panel2 <- function (size,int="r"){
 mat <- matrix(1:2,2,1,byrow=T)
 layout(mat, widths=rep(size,2), heights=rep(size/2,2), TRUE)
 par(mar=c(4,4,1,.5),xaxs=int, yaxs=int)
}

panel4 <- function (size,int="r"){
 mat <- matrix(1:4,2,2,byrow=T)
 layout(mat, widths=rep(size/2,2), heights=rep(size/2,2), TRUE)
 par(mar=c(4,4,1,.5),xaxs=int, yaxs=int)
}

panel6 <- function (size,int="r"){
 mat <- matrix(1:6,3,2,byrow=T)
 layout(mat, widths=rep(size/2,2), heights=rep(size/3,3), TRUE)
 par(mar=c(4,4,1,.5),xaxs=int, yaxs=int)
}

panels <- function (wd,ht,rows,cols,pty,int="r"){
 np <- rows*cols # number of panels
 mat <- matrix(1:np,rows,cols,byrow=T) # matrix for layout
 layout(mat, widths=rep(wd/cols,cols), heights=rep(ht/rows,rows), TRUE)
 par(mar=c(4,4,1,.5),xaxs=int,yaxs=int,pty=pty)
}
