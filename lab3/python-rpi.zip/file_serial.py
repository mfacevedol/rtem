import os
import serial
from datetime import datetime,timezone

logfile = "data/datalog.csv"
header = "TimeStamp,Vout,Rt,Temp\n"
if os.path.exists(logfile):
	print("File exists, appending records\n")
	file = open(logfile, "a")
else:
	print("File does not exists, writing header\n")
	print(header)
	file = open(logfile, "w")
	file.write(header)

ser = serial.Serial('/dev/ttyACM0',9600)
while 1:
    if(ser.in_waiting >0):
        line = ser.readline()
        linedec = line.decode('utf-8')
        linestr = str(linedec)
        now = datetime.now(timezone.utc)
        timestamp = str(now.astimezone().strftime("%Y-%m-%d %H:%M:%S %z"))
        print(timestamp+linestr,end="")
        file.write(timestamp+linestr)
        file.flush()

