# WSN Moteino Gateway
# WSN Moteino nodes are senders
# RPI assembles files

import os
from datetime import datetime,timezone
import serial
import time
from time import sleep

logfile = "data/Moteino-datalog.csv"
header = "TimeStamp,Node,Temp(C),RSS(dBm)\n"

if os.path.exists(logfile):
	print("File exists, appending records\n")
	file = open(logfile, "a")
else:
	print("File does not exists, writing header\n")
	print(header)
	file = open(logfile, "w")
	file.write(header)

ser =serial.Serial("/dev/ttyUSB0",9600)
while 1:
	if(ser.in_waiting >0):
		line = ser.readline()
		linedec = line.decode('utf-8')
		linestr = str(linedec)
		print(linestr,end="")
		now = datetime.now(timezone.utc)
		timestamp = str(now.astimezone().strftime("%Y-%m-%d %H:%M:%S %z")+',')
		# parse the incoming line
		#lineParsed = linestr.split(sep=",")
		#print(lineParsed[1])
		#values = lineParsed[0]+','+lineParsed[2]+','+lineParsed[4]
		#record = timestamp+values
		#file.write(record+"\n")
		#file.flush()
		#print(record+"\n")


