# WSN MQTT Subscriber writes datalog files
# WSN MQTT nodes are publishers
# Subscriber runs in the same RPI as the broker

import os
from datetime import datetime,timezone
import serial
import time
from time import sleep
import paho.mqtt.client as mqtt

lognode1 = "data/node1-datalog.csv"
lognode2 = "data/node2-datalog.csv"
header = "TimeStamp,Temp\n"

if os.path.exists(lognode1):
	print("File exists, appending records\n")
	file1 = open(lognode1, "a")
else:
	print("File does not exists, writing header\n")
	print(header)
	file1 = open(lognode1, "w")
	file1.write(header)

if os.path.exists(lognode2):
	print("File exists, appending records\n")
	file2 = open(lognode2, "a")
else:
	print("File does not exists, writing header\n")
	print(header)
	file2 = open(lognode2, "w")
	file2.write(header)

# MQTT broker
mqtt_broker_ip = "192.168.1.132"
mqtt_username = "rtem"
mqtt_password = "dynapop"

# array for two topics the 0 is qos 
mqtt_topic = [("Node1/Temp",0),("Node2/Temp",0)]

# subscriber client
client = mqtt.Client()
client.username_pw_set(mqtt_username, mqtt_password)

# function to run when the MQTT client connects to the broker
def on_connect(client, userdata, flags, rc):
	print("Connected! Error code is ", str(rc))
	client.subscribe(mqtt_topic)

# function to run when a message is received
def on_message(client, userdata, msg):
	payload = str(msg.payload,'utf-8')
	now = datetime.now(timezone.utc)
	timestamp = str(now.astimezone().strftime("%Y-%m-%d %H:%M:%S %z")+',')
	record = timestamp+payload
	print(msg.topic+" ",end="")
	print(record)
	if(msg.topic == 'Node1/Temp'):
		file1.write(record+"\n")
		file1.flush()
	if(msg.topic == 'Node2/Temp'):
		file2.write(record+"\n")
		file2.flush()
		

# functions  to run
client.on_connect = on_connect
client.on_message = on_message

# connect to the broker on port 1883
client.connect(mqtt_broker_ip, 1883)

# let the client run
client.loop_forever()
client.disconnect()
