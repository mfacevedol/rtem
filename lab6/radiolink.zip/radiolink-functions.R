
fsl <- function(f.MHz,d.km,G.dB=0,Pt.dBm=30){
  # PL for unity gain
  FSL.dB <- 20*log10(f.MHz)+20*log10(d.km)+32.45
  # received power in dBm 
  rxp.dBm <- Pt.dBm + G.dB - FSL.dB
  return(list(fMHz.dkm.GdB.PtdBm=c(f.MHz,d.km,G.dB,Pt.dBm),
              FSL.dB=round(FSL.dB,2),rxp.dBm=round(rxp.dBm,2)))
}  

fsl.set <- function(f.MHz,d.km,G.dB=0,Pt.dBm=30,plot=TRUE){
 # Calculating FSL for arrays f.MHz and d.km
 FSL.dB <- sapply(f.MHz,function(f.MHz) fsl(f.MHz,d.km)$FSL.dB)
 rxp.dBm <- sapply(f.MHz,function(f.MHz) fsl(f.MHz,d.km)$rxp.dBm)
 # create tables for results
 FSL.df <- data.frame(FSL.dB,row.names=d.km)
 colnames(FSL.df)=f.MHz
 RXP.df <- data.frame(rxp.dBm,row.names=d.km)
 colnames(RXP.df)=f.MHz
 
  if(plot==TRUE){
   panels(6,6,2,1)
   matplot(d.km,FSL.dB,type="l",xlab="Distance(km)",ylab="FSL (dB)",col=1)
   legend("bottomright",leg=paste(f.MHz,"MHz",sep=' '),lty=1:length(f.MHz),col=1,cex=0.7)  
   matplot(d.km,rxp.dBm,type="l",xlab="Distance(km)",ylab="Rx Power (dBm)",col=1)
   legend("topright",leg=paste(f.MHz,"MHz",sep=' '),lty=1:length(f.MHz),col=1,cex=0.7)  
  }
 return(list(f.MHz=f.MHz,d.km=d.km,FSL.dB=FSL.df,rxp.dBm=RXP.df))
}

wlength <- function(f.MHz){
  c = 3 *10^8 # speed of light
  wl.m <- c/(f.MHz*10^6) # wavelength in m
  return(list(f.MHz=f.MHz,wl.m=round(wl.m,3)))
}

dc.km <- function(f.MHz,ht.hr){
  # crossover distance
  wl.m <- wlength(f.MHz)$wl.m
  d.cross.km <-  (4*pi*ht.hr/wl.m)*10^-3
  return(list(f.MHz=f.MHz,dc.km=round(d.cross.km,2)))
}

two.ray <- function(d.km,ht.hr,G.dB=1,Pt.dBm=30){
  # Calculating PL two ray
  PL.dB <- 40*log10(d.km)+120-20*log10(ht.hr)
  rxp.dBm <- Pt.dBm + G.dB - PL.dB
  return(list(d.km=d.km,PL.dB=round(PL.dB,2),rxp.dBm=round(rxp.dBm,2)))
}

two.ray.set <- function(d.km,ht.hr){
  # Calculating PL two ray
  PL.dB <- sapply(ht.hr,function(ht.hr) two.ray(d.km,ht.hr)$PL.dB)
  rxp.dBm <- sapply(ht.hr,function(ht.hr) two.ray(d.km,ht.hr)$rxp.dBm)
  # create table for results
  PL.df <- data.frame(PL.dB,row.names=d.km)
  colnames(PL.df)=ht.hr
  RXP.df <- data.frame(rxp.dBm,row.names=d.km)
  colnames(RXP.df)=ht.hr
  
  return(list(d.km=d.km,ht.hr=ht.hr,PL.dB=PL.df,rxp.dBm=RXP.df))
}

fresnel.clear <- function(wl.m,h.los,d.km,d1.km,d2.km){
 # Fresnel zone clearance 
 # link distance in km from argument
 # height LoS in m from argument
 # obstacle distance from argument
 d1 <- d1.km*1000
 d2.km <- d.km - d1.km; d2 <- d2.km*1000
 # odd zones
 n=c(1,3,5)
 Fn <- sqrt((n*d1*d2*wl.m)/(d1+d2)) 
 # height of obstacle at d1 in m
 h1 = seq(0,h.los,0.1)
 # clearance
 gap <- h.los - h1 - Fn[1]
 clear.perc <- sapply(gap, function(x) {if(x<0) cov<-100*(Fn[1]+x)/Fn[1] else cov=100})
 # compare
 F1.clear <- h1[which(clear.perc >= 60)]
 h1.max <- F1.clear[length(F1.clear)]
 plot(h1,clear.perc,type="l",lty=1,col=1,
        xlab="Obstacle Height (m)",ylab="Clearance (%)")
 abline(v=h1.max,lty=2); abline(h=60,lty=2)
 return(list(h1=h1,clear.perc=round(clear.perc,0)))
}


