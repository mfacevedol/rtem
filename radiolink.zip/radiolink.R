# First part
# Calculating and plotting FSL
# speed of light
c = 3 *10^8
# frequencies in MHz
f.MHz <- c(900, 2400,5000)
# wavelength in m
wlength.m <- c/(f.MHz*10^6)
# distance in km
d.km <- seq(1,100,1)
# create matrix for results
FSL.dB <- matrix(nrow=length(d.km),ncol=length(f.MHz))
# loss free space model
for (i in 1:length(f.MHz)){ 
FSL.dB[,i] <- 20*log10(f.MHz[i])+20*log10(d.km)+32.45
}
matplot(d.km,FSL.dB,type="l",lwd=2,col=1,grid=TRUE)
grid(nx = NULL, ny = NULL, col = "gray", lty = "dotted",
     lwd = par("lwd"), equilogs = TRUE)

#-----------------------------
# Second part
# Radio link study: received power
# speed of light
c = 3 *10^8
# frequency in Hz
f.wifi = 2.4 * 10^9
f.900 = 0.915 *10^9
# pick one and comment out the other
f <- f.900
#f <- f.wifi
# wavelength in m
wlength.m <- c/f
# link distance in km
d.link.km <- 1.78
# antenna height in m 
ht=25; hr=9
# crossover distance
d.cross.km <-  round(0.001*(4*pi*ht*hr*f/c),2)
# compare
FSM <- d.cross.km >= d.link.km
# loss free space model
FSL <- 20*log10(f/10^6)+20*log10(d.link.km)+32.45
# transmit power in dBm
Pow.t <- 30
# antenna gains in dBi
Gi.t <- 10; Gi.r <- 10 
# received power in dBm 
Pow.r <- Pow.t + Gi.t + Gi.r - FSL
print(round(Pow.r,0))
# ----------------------------------

# Third part
# Fresnel zone clearance 
# speed of light
c = 3 *10^8
# frequency in Hz
f.wifi = 2.4 * 10^9
f <- f.wifi
# wavelength in m
wlength.m <- c/f
# link distance in km
d.link.km <- 2
# height LoS in m
h.los <- 10
# obstacle distance
d1.km = 1; d1 <- d1.km*1000
d2.km <- d.link.km - d1.km; d2 <- d2.km*1000
# odd zones
n=c(1,3,5)
Fn <- sqrt((n*d1*d2*c/f)/(d1+d2)) 
# height of obstacle at d1 in m
h1 = seq(0,h.los,0.1)
# clearance
gap <- h.los - h1 - Fn[1]
clear.perc <- sapply(gap, function(x) {if(x<0) cov<-100*(Fn[1]+x)/Fn[1] else cov=100})
# compare
F1.clear <- h1[which(clear.perc >= 60)]
h1.max <- F1.clear[length(F1.clear)]
plot(h1,clear.perc,type="l",lty=1,col=1,
        xlab="Obstacle Height (m)",ylab="Clearance (%)")
abline(v=h1.max,lty=2); abline(h=60,lty=2)
 


