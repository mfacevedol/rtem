import serial
import datetime
logfile = "labs/data/datalog.csv"
file = open(logfile, "a")

ser = serial.Serial('/dev/ttyACM0',9600)
while 1:
    if(ser.in_waiting >0):
        line = ser.readline()
        linedec = line.decode('utf-8')
        linestr = str(linedec)
        now = datetime.datetime.now()
        timestamp = str(now.astimezone().strftime("%Y-%m-%d %H:%M:%S %Z"))
        print(timestamp+linestr,end="")
        file.write(timestamp+linestr)

