therm.lin <- function(Rt.nom,T.C,S){
 # linear model
 # Rt.nom is list(T0.C, R0.k)
 T.K <- T.C + 273; T0.K <- Rt.nom$T0.C+273
 Rt.k <- Rt.nom$R0.k+S*(T.C-Rt.nom$T0.C)
 return(list(Rt.k=round(Rt.k,2),T.C=T.C))
} 

B.param.der <- function(Rt.nom,T.C,B){
 T.K <- T.C + 273; T0.K <- Rt.nom$T0.C+273
 dRt.k <- B*B.param(Rt.nom,T.C,B)$Rt.k*(-1/T.K^2)
 return(list(dRt.k=round(dRt.k,5),T.C=T.C))
}

ckt.div.lin <- function(T.C,Rt.nom,S,Rf.k,R1.k,Vs){
 Rt.k <- therm.lin(Rt.nom,T.C,S)$Rt.k
 R <- R1.k + Rt.k + Rf.k
 Vout <- Vs*Rf.k/R
 Pow <- (Vs/R)^2*Rt.k
 return(list(T.C=T.C,Vout=round(Vout,3),Pow.mW=round(Pow,3)))
}

ckt.bal.div <- function(T.C,Rt.nom,B,Rf.k,Vs){
 #Rt.k <- therm.lin(Rt.nom,T.C,S)$Rt.k
 Rt.k <- B.param(Rt.nom,T.C,B)$Rt.k
 R <- Rf.k + Rt.k
 Vout <- Vs*(Rf.k - Rt.k)/R
 Pow <- (Vs/R)^2*Rt.k
 return(list(T.C=T.C,Vout=round(Vout,3),Pow.mW=round(Pow,3)))
}

ckt.quart.bridge <- function(T.C,Rt.nom,B,Rf.k,Vs){
 #Rt.k <- therm.lin(Rt.nom,T.C,S)$Rt.k
 Rt.k <- B.param(Rt.nom,T.C,B)$Rt.k
 R <- 2*(Rf.k + Rt.k)
 Vout <- Vs*(Rf.k - Rt.k)/R
 Pow <- (Vs/R)^2*Rt.k
 return(list(T.C=T.C,Vout=round(Vout,3),Pow.mW=round(Pow,3)))
}

ckt.lin.bridge <- function(T.C,Rt.nom,B,Rf.k,Vs){
 Rt.k <- B.param(Rt.nom,T.C,B)$Rt.k
 R <- 2*Rf.k
 Vout <- Vs*(-(Rt.k-Rf.k)/R)
 Pow <- (Vs/R)^2*Rt.k
 return(list(T.C=T.C,Vout=round(Vout,3),Pow.mW=round(Pow,3)))
}

ckt.lin.bridge.bias <- function(T.C,Rt.nom,S,Rf.k,Vs){
 Rt.k <- therm.lin(Rt.nom,T.C,S)$Rt.k
 # full calculation
 R <- 2*Rf.k
 A <- (Rt.k/Rf.k)*(0.5*(1+(Rf.k/Rt.k)) -1) 
 # simplified calc: can be use to demonstrate teh same result
 #A <- -(Rt.k-Rf.k)/R
 Vout <- Vs*A
 Pow <- (Vs/R)^2*Rt.k
 return(list(T.C=T.C,Vout=round(Vout,3),Pow.mW=round(Pow,3)))
}

read.bipolar <- function(Vs,nbits,v){
 # read a bipolar signal using voltage divider from Vs to signal
 # v is a bipolar signal example v <- c(-5,-2,-1,-0.5,0,0.5,1,2,5)
 maxd <- 2^nbits-1
 # biased to get unipolar into arduino
 v1 <- (Vs-v)/2
 # digital number read by arduino
 din <- v1*(maxd)/Vs
 # subtract half point
 din1 <-  din-maxd/2 
 # convert to voltage
 v2 <- -2*din1*Vs/maxd
 return(vread = round(v2,3))
}


