# Snell's law water and air interface
perm.r <- 80
mat <- matrix(1:2, 2, 1, byrow = T)
layout(mat, widths = rep(30,2), heights = rep(30,2), respect=F)
par(mar = c(5, 8, 1, 8),cex=0.8)

theta.i <- seq(0,90,01); rad.i <- theta.i*pi/180
sin.rad.t <- sin(rad.i)/sqrt(perm.r)
rad.t <- asin(sin.rad.t)
theta.t <- rad.t*180/pi 
plot(theta.i,theta.t,type="l",
     xlab="Incidence angle (degrees)",
     ylab= "Transmission angle (degrees)")
abline(h=6.42,lty=2)
text(50,3,"Air to Water",cex=0.8)

theta.i <- seq(0,8,0.01); rad.i <- theta.i*pi/180
sin.rad.t <- sqrt(perm.r)*sin(rad.i)
rad.t <- asin(sin.rad.t)
theta.t <- rad.t*180/pi 
plot(theta.i,theta.t,type="l",
     xlab="Incidence angle (degrees)",
     ylab= "Transmission angle (degrees)")
abline(v=6.42,lty=2)
text(1,60,"Water to Air",cex=0.8)


