spp.div <- function(x){
 nx <- length(x); sx <- sum(x)
 ns <-0; xx <- array()
 for (i in 1:nx){
  if (x[i]>0){
    ns<- ns+1
    xx[ns]<- x[i]
   } 
  }
  # pmf
  p <- xx/sx
  # entropy
  H <- round(sum(-p*log2(p)),2)
 # ns is number of species or spp richnesss
 # H is species diversity measured by Shannon's entropy
 return(list(ns=ns,H=H))
}

