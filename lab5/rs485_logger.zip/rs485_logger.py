import os
from datetime import datetime,timezone
import serial
import RPi.GPIO as GPIO
import time
from time import sleep

# serial channel for RS-485
rs485  = serial.Serial(
	port='/dev/serial0',
	baudrate = 9600,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
	timeout=1
)

logfile = "data/rs485-datalog.csv"
header = "TimeStamp,Vout,EC,TDS\n"

if os.path.exists(logfile):
	print("File exists, appending records\n")
	file = open(logfile, "a")
else:
	print("File does not exists, writing header\n")
	print(header)
	file = open(logfile, "w")
	file.write(header)

try:
	GPIO.setmode(GPIO.BOARD)
	# GPIO number in setup refers to pin number on the header
	# in this example pin number 7 is GPIO4 
	GPIO.setup(7, GPIO.OUT)


	while 1:
		print("Sending cmd and sid to read sensor")
		cmd = 'r'
		sid = '2'
		GPIO.output(7, GPIO.HIGH)
		time.sleep(0.5)
		rs485.write(bytes(cmd,'utf-8'))
		rs485.write(bytes(sid,'utf-8'))
		print("cmd= ",cmd,"sid= ", sid)

		print("Listen for input")
		GPIO.output(7, GPIO.LOW)
		time.sleep(0.5)
		
		if(rs485.in_waiting >0):
			line = rs485.readline()
			linedec = line.decode('utf-8')
			linestr = str(linedec)
			now = datetime.now(timezone.utc)
			timestamp = str(now.astimezone().strftime("%Y-%m-%d %H:%M:%S %z")+',')
			print(timestamp,linestr,end="")
			file.write(timestamp+linestr)
			file.flush()
		time.sleep(5)

#print this if CTRL + C is used to stop python script
except KeyboardInterrupt:
	print("Program interrupted")
finally:
	GPIO.cleanup()
