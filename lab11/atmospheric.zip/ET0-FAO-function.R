
et0.fao <- function(albedo=0.23,soil=0.0, Temp.C, RH, Rad.MJ, BarP.kPa, Wind2m.mps){ 
# Penman-Monteith
# Temp in degC, RH in %, Rad in MJ/m2, BarP in kPa, Wind2m in m/s 
# convert to deg Kelvin
Temp.K <- Temp.C + 273

# water vapor pressure at saturation in kPa
satura <- 0.6108* exp(17.27*Temp.C/(Temp.C+237.3))
# slope in kPa/C
slope <- 4096*satura/(Temp.C+237.3)^2
# psychrometer constant a function of pressure Kpa
psychro <- 0.7*10^-3*BarP.kPa
# vapor pressure using RH
vap.press <- satura*RH/100
deficit <- satura - vap.press
latent.heat <- 2.50 - 0.0022*Temp.C # MJ/kg

denom <- slope+psychro*(1+0.34*Wind2m.mps)
netrad <- (Rad.MJ*(1-albedo))*(1-soil)/latent.heat  

rad.term <- slope*netrad/denom
aero.term <- psychro*(37/Temp.K)*Wind2m.mps*deficit/denom
et0 <- rad.term+aero.term
return(et0)
}

