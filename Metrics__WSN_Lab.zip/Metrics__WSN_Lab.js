﻿//This sample metric will override that which is already defined in main core.js
//You can redefine defaults or write your own new custom metrics in 1 or more files in this folder, separate them as you'd like - they all get merged together when the app loads

exports.metrics = 
{  
  min:
  {
    name: 'Minutes',
    regexp: /\bmin\:([\d\.]+)\b/i,
    value: '',
    duplicateInterval: 60,
    unit: ' minutes',
    graph: 1,
    graphOptions:
    {
      legendLbl: 'Minutes',
      lines:
      {
        fill: true,
        lineWidth: 1
      },
      yaxis:
      {
        min: 0,
        autoscaleMargin: 0.25
      }
    }
  }, 
  
  Vout:
  {
    name: 'Divider Output Voltage',
    regexp: /\bVout\:([\d\.]+)\b/i,
    value: '',
    duplicateInterval: 60,
    unit: ' V',
    graph: 1,
    graphOptions:
    {
      legendLbl: 'Thermistor Output Voltage(V)',
      lines:
      {
        fill: true,
        lineWidth: 1
      },
      yaxis:
      {
        min: 0,
        max: 3.3,
        autoscaleMargin: 0.25
      }
    }
  }, 

  RTk:
  {
    name: 'Thermistor Resistance',
    regexp: /\bRTk\:([\d\.]+)\b/i,
    value: '',
    duplicateInterval: 60,
    unit: ' Ohm',
    graph: 1,
    graphOptions:
    {
      legendLbl: 'Resistance(Ohm)',
      lines:
      {
        fill: true,
        lineWidth: 1
      },
      yaxis:
      {
        min: 5,
        max: 15,
        autoscaleMargin: 0.25
      }
    }
  }, 
  
  
  Ta:
  {
    name: 'Ambient temperature',
    regexp: /\bTa\:([\d\.]+)\b/i,
    value: '',
    duplicateInterval: 60,
    unit: ' C',
    graph: 1,
    graphOptions:
    {
      legendLbl: 'Ambient Temperature (C)',
      lines:
      {
        fill: true,
        lineWidth: 1
      },
      yaxis:
      {
        min: 15,
        max: 40,
        autoscaleMargin: 0.25
      }
    }
  }, 

  Tr:
  {
    name: 'Radio Temperature',
    regexp: /\bTr\:([\d\.]+)\b/i,
    value: '',
    duplicateInterval: 60,
    unit: ' C',
    graph: 1,
    graphOptions:
    {
      legendLbl: 'Thermistor Temperature (C)',
      lines:
      {
        fill: true,
        lineWidth: 1
      },
      yaxis:
      {
        min: 15,
        max: 50,
        autoscaleMargin: 0.25
      }
    }
  }, 

  SM:
  {
    name: 'Soil Moisture',
    regexp: /\bSM\:([\d\.]+)\b/i,
    value: '',
    duplicateInterval: 60,
    unit: '%',
    graph: 1,
    graphOptions:
    {
      legendLbl: 'Soil Moisture(%)',
      lines:
      {
        fill: true,
        lineWidth: 1
      },
      yaxis:
      {
        min: 0,
        autoscaleMargin: 0.25
      }
    }
  },

  PktLen:
  {
    name: 'Packet Length',
    regexp: /\bPktLen\:([\d\.]+)\b/i,
    value: '',
    duplicateInterval: 60,
    unit: ' byte',
    graph: 1,
    graphOptions:
    {
      legendLbl: 'Packet Length (byte)',
      lines:
      {
        fill: true,
        lineWidth: 1
      },
      yaxis:
      {
        min: 0,
        autoscaleMargin: 0.25
      }
    }
  }, 


   RSL: 
      { 
       name:'Receive Signal Level', 
       regexp:/\[(?:RSL|SS)\:(-?\d+)[^\s]*\]/i, 
       value:'', 
       duplicateInterval:60,
       unit:' dBm', 
       graph:1, 
       graphOptions:
       { 
         legendLbl:'Signal Strength (dBm)', 
         lines: 
         { 
           fill:true, 
           lineWidth:1 
         }, 
         grid: 
         { 
          backgroundColor: 
          {
           colors:['#000', '#03c', '#08c']
          }
         }, 
         yaxis: 
         { 
         min:-100, 
         max:-20 
         }
        }
      },
   
};
exports.motes = {
  LabMote: {
    label  : 'Lab Sensor',
    icon   : 'labnode.png',
  },
}

